# Cold-start DEP: limited history + preference enrichment

Code for the SOP "Improving DEP-Based LLM Personalization under Cold-Start / Limited User History".
It plugs into the official repo https://github.com/SnowCharmQ/DEP (copy the `coldstart/` folder into its root).

## What is implemented
| SOP item | File |
|---|---|
| Controlled 1 / 2 / 5-review history sets (same users, targets, peers) | `coldstart/build_coldstart.py` |
| Proposed preference-enrichment module (rule-based, CPU, no API) | `coldstart/enrich.py` |
| Original vs modified evaluation, same metrics as the official eval | `coldstart/eval_coldstart.py` |
| Table I + relative change | `coldstart/make_table.py` |
| Qualitative examples | `coldstart/show_examples.py` |
| Sanity tests (CPU, synthetic data) | `tests/test_coldstart.py` |

Variants compared at each K:
* `orig`          - DEP as released, only K reviews available
* `enrich_text`   - + preference profile text in the prompt
* `enrich_blend`  - + profile embedding blended into the user representation before inter-user difference modeling (`--alpha`)

## Run (official repo root)
```bash
bash install.sh                       # official env (forked vLLM!)
python embedding.py                   # bge-m3 embeddings of all test users
python -m coldstart.build_coldstart --ks 1 2 5 --limit 200      # start small
for K in 1 2 5; do for V in orig enrich_text enrich_blend; do
  python -m coldstart.eval_coldstart --category Books --k $K --variant $V --mode infer --limit 200
  python -m coldstart.eval_coldstart --category Books --k $K --variant $V --mode eval  --limit 200
done; done
python -m coldstart.eval_coldstart --category Books --k full --mode infer --limit 200   # needs run-create.sh first
python -m coldstart.eval_coldstart --category Books --k full --mode eval  --limit 200
python -m coldstart.make_table
python -m coldstart.show_examples --category Books --k 2 --n 5
```

## Design decisions worth knowing
1. **No history leak.** The official code weights peers using the target user's mean over their *whole* profile
   (`user_prof_mean_emb_map`). Here the mean is computed from the K available reviews only
   (tested in `test_no_full_history_leak`).
2. **Fixed 16 x 1024 layout.** The DEP vLLM fork allocates a `(16, 1024)` buffer per request and swaps embeddings in by
   token id, so K < 8 histories are zero-padded: rows 0-7 = reviews, rows 8-15 = differences.
3. **Row/token alignment.** Review *i* in the prompt (i-th most recent) uses embedding row *i*. In the official dataset code the
   prompt's i-th review and the i-th *embedding* can refer to different reviews when some recent reviews have no peers.
4. **Reviews without peers** get no difference token (instead of a zero vector the model never saw in training).
5. The system prompt is unchanged in all variants; only the `[User Preference Profile]` block differs.
6. `--seed` fixes each request's sampling seed (official eval has none) so variants are comparable.

## Caveats
* Not run on the real data/model: written and tested on synthetic data only. No performance claims.
* Qwen2.5-7B in bf16 does **not** fit/run on a Colab T4 (no bf16, 15 GB). Use L4/A100 (or `--dtype float16` on >=24 GB).
  `--limit` keeps runs short.
* `enrich_blend` mixes a profile-summary embedding with review embeddings that the released SAE was never trained on;
  treat it as an ablation, not the main method.
